import requests
import time
import random
import datetime
#import hvac
from boxsdk import Client, JWTAuth
from cryptography.hazmat.primitives.serialization import load_pem_private_key
from cryptography.hazmat.backends import default_backend
import re
import json
from boxsdk.object.collaboration_allowlist import AllowlistDirection

autoFormId = 1115080
denyDomainId = 1165960

vault_token = '@option.vault_token@'

# function to connect to the vault @option.vault_token@
# 1st change
# def vault_connect(vault_token):
#     client = hvac.Client(
#     url='https://dwt-vault.cloud.corporate.ge.com',
#     token=vault_token,
#     )
#     return client

def get_credentials():

    # Example usage
    server = "alpwincark01.hcad.ds.ge-healthcare.net"
    app_id = "1101269986-P"
    user = "Joq0ogPmHrGLWStuhHIUzZDR8HeAGVIbfDJQNG72uTPItIDE"
    safe = "00_02_NMG_1101269986-P"

    # Construct the URL for the API call
    url = f"https://{server}/AIMWebService/api/Accounts?AppID={app_id}&Safe={safe}&Query=Username={user}"

    # Make the API call to get username and password
    response = requests.get(url)
    if response.ok:
        response_info = response.json()
        username = response_info['UserName']
        password = response_info['Content']
        return username, password
    else:
        raise Exception(f"Error fetching credentials: {response.status_code} - {response.text}")



try:
    username, password = get_credentials()
    #print(f"Username: {username}, Password: {password}")
except Exception as e:
    print(e)

#def vault_connect(password):
def vault_connect(username,password):

    data = {
        "username": username,
        "password": password
    }

    attempts = 0
    while True:
        try:
            #token_request = requests.post("https://dwt-vault.cloud.corporate.ge.com/v1/auth/ldap/login/504005682",json=data).json()['auth']['client_token']
            #url = f"https://fssfed.ge.com/fss/as/token.oauth2?grant_type=client_credentials&client_id={username}&client_secret={password}&scope=api"
            url = f"https://efs.sso.gehealthcare.com/fss/as/token.oauth2?grant_type=client_credentials&client_id={username}&client_secret={password}&scope=api"
            payload = {}
            headers = {}
            # Make the second API call
            token_request = requests.post(url, headers=headers, data=payload)
            # Print the response from the second API call
            if token_request.ok:
                token_info = token_request.json()
                access_token = token_info['access_token']
                token_type = token_info['token_type']
                expires_in = token_info['expires_in']

        except Exception as e:
            print(e)
            if attempts < 5:
                time.sleep(300)
            else:
                print("Unable to get token from vault.")
                sys.exit(1)
        else:
            print('token_request:',token_request.json())
            print('\ntoken from token request:', access_token)
            return access_token #token_request

# function to get box client given box client settings






# function to get box client given box client settings
# 2nd Changes
# def get_box_client(box_settings):

#     appAuth = box_settings["boxAppSettings"]["appAuth"]
#     privateKey = appAuth["privateKey"]
#     passphrase = appAuth["passphrase"]

#     # https://cryptography.io/en/latest/
#     key = load_pem_private_key(
#         data=privateKey.encode('utf8'),
#         password=passphrase.encode('utf8'),
#         backend=default_backend(),
#     )

#     # information to connect to the box API using the developer portal information
#     auth = JWTAuth (
#         client_id = box_settings["boxAppSettings"]["clientID"],
#         client_secret = box_settings["boxAppSettings"]["clientSecret"],
#         enterprise_id = box_settings["enterpriseID"],
#         jwt_key_id = box_settings["boxAppSettings"]["appAuth"]["publicKeyID"],
#         rsa_private_key_data = key
#     )

#     client = Client(auth)

#     return client

def get_box_client(box_settings):


    appAuth = box_settings["boxAppSettings"]["appAuth"]
    privateKey = appAuth["privateKey"]
    passphrase = appAuth["passphrase"]

    # https://cryptography.io/en/latest/
    key = load_pem_private_key(
        data=privateKey.encode('utf8'),
        password=passphrase.encode('utf8'),
        backend=default_backend(),
    )

    # information to connect to the box API using the developer portal information
    auth = JWTAuth (
        client_id = box_settings["boxAppSettings"]["clientID"],
        client_secret = box_settings["boxAppSettings"]["clientSecret"],

        enterprise_id = box_settings["enterpriseID"],
        jwt_key_id = box_settings["boxAppSettings"]["appAuth"]["publicKeyID"],
        rsa_private_key_data = key
    )

    client = Client(auth)

    return client

# function to create session to generic read service and generate ge tokens when expired
# def geApiSession(timeout):

#     now = datetime.datetime.now()
    
#     if "ge_access_token" not in globals():
#         global ge_access_token
#         global token_timeout

#     if "form_api_session" not in globals():
#         global form_api_session
#         form_api_session = requests.Session()

#     if now >= timeout:

#         print("Getting new GE API token. Current is expired.")
#         attempts = 1
#         while attempts <= 5:
#             try:
#                 geToken = requests.post('https://fssfed.ge.com/fss/as/token.oauth2?grant_type=client_credentials&client_id={}&client_secret={}&scope=api'.format(oauth['clientId'],oauth['secret']))
#             except:
#                 print("token error")
#                 attempts += 1
#                 time.sleep(random.randint(5,20) * attempts)
#             else:

#                 headers = {
#                     "Authorization": "Bearer {}".format(geToken.json()["access_token"]),
#                     "SM_USER": '504005682',
#                     "Content-Type": "application/JSON"
#                 }

#                 form_api_session.headers.update(headers)
#                 token_timeout = now + datetime.timedelta(seconds=geToken.json()['expires_in'] - 120)
#                 break

def geApiSession(timeout):

    now = datetime.datetime.now()

    if "ge_access_token" not in globals():
        global ge_access_token
        global token_timeout

    if "form_api_session" not in globals():
        global form_api_session
        form_api_session = requests.Session()

    if now >= timeout:

        print("Getting new GE API token. Current is expired.")
        attempts = 1
        while attempts <= 5:
            try:
                #geToken = requests.post('https://fssfed.ge.com/fss/as/token.oauth2?grant_type=client_credentials&client_id={}&client_secret={}&scope=api'.f>
                username, password = get_credentials()
                print('Username:', username)
                print('\nPassword:', password)
                #url = f"https://fssfed.ge.com/fss/as/token.oauth2?grant_type=client_credentials&client_id={username}&client_secret={password}&scope=api"
                url = f"https://efs.sso.gehealthcare.com/fss/as/token.oauth2?grant_type=client_credentials&client_id={username}&client_secret={password}&scope=api"
                print('url:', url)
                payload = {}
                headers = {}

                # Make the second API call
                geToken = requests.post(url, headers=headers, data=payload)

                if geToken.ok:
                    token_info = geToken.json()
                    access_token = token_info['access_token']
                    token_type = token_info['token_type']
                    expires_in = token_info['expires_in']

                    print('\nAccess Token-Second call:', access_token)
                    print('\ngeToken json :', geToken.json())
                    #print('Token Type:', token_type)
                    #print('Expires In:', expires_in)
                else:
                    print('\nError Code ' + str(geToken.status_code))
                    print(geToken.text)

            except:
                print("\ntoken error")
                attempts += 1
                time.sleep(random.randint(5,20) * attempts)
            else:

                headers = {
                    "Authorization": "Bearer {}".format(geToken.json()["access_token"]),
                    "SM_USER": 'NP700002342', #'504005682',
                    "Content-Type": "application/JSON"
                }

                form_api_session.headers.update(headers)
                token_timeout = now + datetime.timedelta(seconds=geToken.json()['expires_in'] - 120)
                break

#function to pull user information from GE LDAP using the generic read service
def formRequestsLookup(id,filter_field,filter_type,filter_value):

    if "token_timeout" in globals():
        geApiSession(token_timeout)
    else:
        geApiSession(datetime.datetime.now())

    formFields = formFieldsLookup(id).json()

    if filter_type == "choice":
        for field in formFields['fields']:
            if field['display_name'] == filter_field:
                field_id = field['field_id']
                for choice in field['choices']:
                    if choice['label'] == filter_value:
                        filter = choice['id']
    elif filter_type == "string":
        for field in formFields['fields']:
            if field['display_name'] == filter_field:
                field_id = field['field_id']
                filter = filter_value

    body = {
        "offset":0,"limit":50,
            "filters":{
                "andor":[{
                    "field_id":f"{field_id}","operator":"eq","conjuction":"","value":filter,"operatorName":"ne","operatorvalue":"","id":1
                }],
                "filterCriteria":"filter_1","sort":{"field_id":"dt_updated","order":"desc"}},
                "sort":{"field_id":"dt_updated","order":"desc"},
                "parent_record_id":0,
                "case_sensitive":False
            }
        
    attempts = 0
    while True:
        try:
            attempts += 1
            geApiSession(token_timeout)
            #formQuery = form_api_session.post(f'https://api.ge.com/digital/ngformsv3/api/v3/forms/{id}/records',timeout = 60,json=body)
            formQuery = form_api_session.post(f'https://prod-api.gehealthcare.com/digital/formsv3_2l/api/v3/forms/{id}/records',timeout = 60,json=body)
        except Exception as e:
            print(f"GE API request exception triggered. Trying again. Attempt: {attempts}")
            print(e)
            if attempts == 10:
                print("Forms API request exeptions hit maximum attempts")
                break
            else:
                time.sleep(5 * attempts)
                continue
        else:
            return formQuery

def formFieldsLookup(id):
    
    if "token_timeout" in globals():
        geApiSession(token_timeout)
    else:
        geApiSession(datetime.datetime.now())

    attempts = 0
    while True:
        try:
            attempts += 1
            geApiSession(token_timeout)
            #formFields = form_api_session.get(f'https://api.ge.com/digital/ngformsv3/api/v3/forms/{id}',timeout = 60)
            formFields = form_api_session.get(f'https://prod-api.gehealthcare.com/digital/formsv3_2l/api/v3/forms/{id}',timeout = 60)
        except Exception as e:
            print(f"GE API request exception triggered. Trying again. Attempt: {attempts}")
            print(e)
            if attempts == 10:
                print("Forms API request exeptions hit maximum attempts")
                break
            else:
                time.sleep(5 * attempts)
                continue
        else:
            break

    
    return formFields

def formRecordLookup(id):

    if "token_timeout" in globals():
        geApiSession(token_timeout)
    else:
        geApiSession(datetime.datetime.now())

    attempts = 0
    while True:
        try:
            attempts += 1
            #recordQuery = form_api_session.get(f"https://api.ge.com/digital/ngformsv3/api/v3/records/{id}",timeout = 60)
            recordQuery = form_api_session.get(f"https://prod-api.gehealthcare.com/digital/formsv3_2l/api/v3/records/{id}",timeout = 60)
        except Exception as e:
            print(f"GE API request exception triggered. Trying again. Attempt: {attempts}")
            print(e)
            if attempts == 10:
                print("Forms API request exeptions hit maximum attempts")
                break
            else:
                time.sleep(5 * attempts)
                continue
        else:
            break
    
    return recordQuery

def createRequest(autoFormId,userFormId,request):

    if "token_timeout" in globals():
        geApiSession(token_timeout)
    else:
        geApiSession(datetime.datetime.now())

    recordQuery = formRecordLookup(request['record_id'])
    userFormFields = formFieldsLookup(userFormId)
    autoFormFields = formFieldsLookup(autoFormId)
    
    userData = {}
    for field in userFormFields.json()['fields']:
        if 'enclosed_fields' in field:
            for id in field['enclosed_fields']:
                for dataField in userFormFields.json()['fields']:
                    if str(dataField['field_id']) == id:
                        userData.update({
                            dataField['field_id']: dataField
                        }
                        )
    
    # matching the field ID's of the user form to fill out the fields in the automation form
    # we match the display names of the user form field to the auto form field
    # unless the field is a choices field, we match the label of the choice to the choice in the automation form
    body = {}
    for field in autoFormFields.json()['fields']:
        if 'enclosed_fields' in field:
            for id in field['enclosed_fields']:
                for autoField in autoFormFields.json()['fields']:
                    if str(autoField['field_id']) == id:
                        for fieldId in userData:
                            if userData[fieldId]['display_name'] in autoField['display_name']:
                                if "choices" not in autoField:
                                    if recordQuery.json()["field_" + str(fieldId)][0] != "":
                                        matched_field = recordQuery.json()["field_" + str(fieldId)]
                                    else:
                                        matched_field = None
                                else:
                                    for choice in autoField['choices']:
                                        if choice['label'] == request[f'field_{fieldId}'][0]:
                                            matched_field = [str(choice['id'])]
                                            break
                                        else:
                                            matched_field = None
                                
                                if matched_field is not None:
                                    if (autoField['field_type'] == 'peoplesearch') or (autoField['field_type'] == 'select'):
                                        matched_field = [int(matched_field[0])]
                                    elif autoField['field_type'] == 'radio':
                                        matched_field = [str(matched_field[0])]
                                    else:
                                        matched_field = [str(matched_field[0])]

                                    body.update({
                                        "field_" + str(autoField['field_id']): matched_field
                                    })
    
    # grabbing the field id of the people search field
    # in order to create the request impersonating the user who needs personal data from the record
    for userDataFieldId in userData:
        if (userData[userDataFieldId]['field_type'] == 'peoplesearch'):
            body.update({
                "proxy_created_by": int(recordQuery.json()[f"field_{userData[userDataFieldId]['field_id']}"][0])
            })
            break

    body.update({
        "form_id": str(autoFormId)
    }
    )
    print(body)

    attempts = 0
    while True:
        try:
            attempts += 1
            #createRequestOutput = form_api_session.post(f'https://api.ge.com/digital/ngformsv3/api/v3/forms/{autoFormId}/record',timeout = 60,json=body)
            createRequestOutput = form_api_session.post(f'https://prod-api.gehealthcare.com/digital/formsv3_2l/api/v3/forms/{autoFormId}/record',timeout = 60,json=body)
        except Exception as e:
            print(f"GE API request exception triggered. Trying again. Attempt: {attempts}")
            print(e)
            if attempts == 10:
                print("Forms API request exeptions hit maximum attempts")
                break
            else:
                time.sleep(5 * attempts)
                continue
        else:
            break
    
    return createRequestOutput

def updateRecord(formId,recordId,updateField,fieldType,updateValue):
    
    if "token_timeout" in globals():
        geApiSession(token_timeout)
    else:
        geApiSession(datetime.datetime.now())
    
    formFields = formFieldsLookup(formId).json()

    body = {
        "record_id": f"{recordId}",
        "form_id": f"{formId}"
    }

    for field in formFields['fields']:
        if field['display_name'] == updateField:
            if fieldType == "choice":
                for choice in field['choices']:
                    if choice['label'] == updateValue:
                        body.update({
                            f"field_{field['field_id']}": [str(choice['id'])]
                        })
            elif fieldType == "date":
                body.update({
                    f"field_{field['field_id']}": [updateValue.strftime('%Y-%m-%d %H:%M')]
                })
            elif fieldType == "string":
                body.update({
                    f"field_{field['field_id']}": [updateValue]
                })

    attempts = 0
    while True:
        try:
            attempts += 1
            #recordUpdate = form_api_session.put(f"https://api.ge.com/digital/ngformsv3/api/v3/records/{recordId}",timeout = 60,json=body)
            recordUpdate = form_api_session.put(f"https://prod-api.gehealthcare.com/digital/formsv3_2l/api/v3/records/{recordId}",timeout = 60,json=body)
        except Exception as e:
            print(f"GE API request exception triggered. Trying again. Attempt: {attempts}")
            print(e)
            if attempts == 10:
                print("Forms API request exeptions hit maximum attempts")
                break
            else:
                time.sleep(5 * attempts)
                continue
        else:
            break
    
    return recordUpdate

def boxGetDomainList():
    domain_dict = {}
    allowlist_entries = box_client.collaboration_allowlist().get_entries()
    count = 0
    for entry in allowlist_entries:
        count += 1
        if count % 1000 == 0:
            print(f"counted {count} domains.")
        direction = entry.direction if entry.direction != 'both' else 'bidirectional'
        domain_dict.update({
            (entry.domain).casefold(): direction
        })
    
    return domain_dict

def boxAddAllowedDomain(domain):
    allowlist_entry = box_client.collaboration_allowlist().add_domain(domain, direction=AllowlistDirection.BOTH)
    return allowlist_entry

# gathering tokens from Vault to connect to box sdk and generic read service
#vault_client = vault_connect(vault_token)
vault_client = vault_connect(username,password)
#token = vault_client.secrets.kv.v1.read_secret(path='box/prod/domain_allow_and_personal_data_requests/healthcare/GEHC_Box_PDR_Connector_11857328550')['data']
#oauth = vault_client.secrets.kv.v1.read_secret(path='box/prod/domain_allow_and_personal_data_requests/healthcare/oauth')['data']

#box_client = get_box_client(token)
#box_client = get_box_client(vault_client)

with open('/etc/rundeck/box_settings.json', 'r') as json_file:
    box_settings = json.load(json_file)


#box_client = get_box_client(token)
box_client = get_box_client(box_settings)



# gathering requests from user form to start automation workflow
domainRequests = formRequestsLookup(autoFormId,"processed","choice","No").json()

# denyFormFields = formFieldsLookup(denyDomainId).json()
# for deny_field in denyFormFields['fields']:
#     if deny_field['display_name'] == "domain":
#         denyField = f"field_{deny_field['field_id']}"

# deny_domains = []
# for denyDomain in denyList:
#     deny_domains.append(denyDomain[denyField][0])

if len(domainRequests) != 1:
    domainDict = boxGetDomainList()
    for request in domainRequests['records']:
        domain_list = []
        deny_list = {}
        formFields = formFieldsLookup(autoFormId).json()
        for field in formFields['fields']:
            if field['display_name'] == "domains":
                domains = re.split(" ",re.sub(","," ",request[f"field_{field['field_id']}"][0]))
                for domain in domains:
                    if domain != '':
                        if '@' in domain:
                            domain = re.sub("^.*?@","",domain)
                        if re.match("^((?!-)[A-Za-z0-9-]{1,63}(?<!-)\\.)+[A-Za-z]{2,6}$",domain):
                            deny_lookup = formRequestsLookup(denyDomainId,"domain","string",domain)
                            if deny_lookup.status_code == 200:
                                if 'error' in deny_lookup.json():
                                    if deny_lookup.json()['error'] == "There are no records for the given form":
                                        domain_list.append(domain)
                                else:
                                    for record in deny_lookup.json()['records']:
                                        for recordField in record:
                                            if domain in record[recordField]:
                                                deny_list.update({
                                                    "{}".format(domain): "This domain is not permitted in GE's Box tenant."
                                                })
                        else:
                            deny_list.update({
                                "{}".format(domain): "Invalid formatting"
                            })
        
        domain_add_list = []
        for domain in domain_list:
            if domain.casefold() in domainDict:
                deny_list.update({
                    "{}".format(domain): "Already added to allowed domain list"
                })
            else:
                addDomainResult = boxAddAllowedDomain(domain)
                if 'domain' in  addDomainResult.response_object:
                    if addDomainResult.response_object['domain'] == domain:
                        domain_add_list.append(domain)
                    else:
                        deny_list.update({
                            f"{domain}": "Box rejected domain addition. Please contact GE's box support team."
                        })
                else:
                    deny_list.update({
                            f"{domain}": "Box failed to add domain. Please contact GE's box support team."
                        })    
        
        if len(domain_add_list) > 0:
            count = 0
            domain_add_results = ""
            for domain in domain_add_list:
                count += 1
                if count < len(domain_add_list):
                    domain_add_results = domain_add_results + domain + ", "
                else:
                    domain_add_results = domain_add_results + domain
        
            updateRecord(autoFormId,request['record_id'],"allowed_domains","string",domain_add_results)
        
        if len(deny_list) > 0:
            count = 0
            domain_deny_results = ""
            for domain in deny_list:
                count += 1
                if count < len(deny_list):
                    domain_deny_results = domain_deny_results + "Domain: " + domain + f" Reason: {deny_list[domain]}" + ", "
                else:
                    domain_deny_results = domain_deny_results + "Domain: " + domain + f" Reason: {deny_list[domain]}"

            updateRecord(autoFormId,request['record_id'],"denied_domains","string",domain_deny_results)
        
        if (len(deny_list) > 0) and (len(domain_add_list) > 0):
            updateRecord(autoFormId,request['record_id'],"domain_result","choice","Partial")
        elif (len(deny_list)) > 0:
            updateRecord(autoFormId,request['record_id'],"domain_result","choice","Denied")
        elif len(domain_add_list) > 0:
            updateRecord(autoFormId,request['record_id'],"domain_result","choice","Allowed")

        updateRecord(autoFormId,request['record_id'],"processed","choice","Yes")
