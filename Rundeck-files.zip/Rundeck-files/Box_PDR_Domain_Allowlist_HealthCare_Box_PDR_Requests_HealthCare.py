import requests
import time
import random
import datetime
from datetime import timedelta
import boxsdk #install module boxsdk
from boxsdk import Client, JWTAuth
from cryptography.hazmat.primitives.serialization import load_pem_private_key
from cryptography.hazmat.backends import default_backend
import sys
import json

autoFormId = 1065628
userFormId = 1066408
folderFormId = 1066448
box_folder_id = 184854554922

# password for service account @option.service_account@
#password = '@option.service_account@'
import requests

def get_credentials():

    # Example usage
    server = "alpwincark01.hcad.ds.ge-healthcare.net"
    app_id = "1101269986-P"
    user = "Joq0ogPmHrGLWStuhHIUzZDR8HeAGVIbfDJQNG72uTPItIDE"
    safe = "00_02_NMG_1101269986-P"

    # Construct the URL for the API call
    url = f"https://{server}/AIMWebService/api/Accounts?AppID={app_id}&Safe={safe}&Query=Username={user}"
    
    # Make the API call to get username and password
    response = requests.get(url)
    if response.ok:
        response_info = response.json()
        username = response_info['UserName']
        password = response_info['Content']
        return username, password
    else:
        raise Exception(f"Error fetching credentials: {response.status_code} - {response.text}")



try:
    username, password = get_credentials()
    #print(f"Username: {username}, Password: {password}")
except Exception as e:
    print(e)



# function to connect to the vault
#def vault_connect(password):
def vault_connect(username,password):

    data = {
        "username": username,
        "password": password
    }

    attempts = 0
    while True:
        try:
            #token_request = requests.post("https://dwt-vault.cloud.corporate.ge.com/v1/auth/ldap/login/504005682",json=data).json()['auth']['client_token']
            #url = f"https://fssfed.ge.com/fss/as/token.oauth2?grant_type=client_credentials&client_id={username}&client_secret={password}&scope=api"
            url = f"https://efs.sso.gehealthcare.com/fss/as/token.oauth2?grant_type=client_credentials&client_id={username}&client_secret={password}&scope=api"
#efs.sso.gehealthcare.com from fssfed.ge.com
            payload = {}
            headers = {}
            # Make the second API call
            token_request = requests.post(url, headers=headers, data=payload)
            # Print the response from the second API call
            if token_request.ok:
                token_info = token_request.json()
                access_token = token_info['access_token']
                token_type = token_info['token_type']
                expires_in = token_info['expires_in']

        except Exception as e:
            print(e)
            if attempts < 5:
                time.sleep(300)
            else:
                print("Unable to get token from vault.")
                sys.exit(1)
        else:
            print('token_request:',token_request.json())
            print('\ntoken from token request:', access_token)
            return access_token #token_request

# function to get box client given box client settings
def get_box_client(box_settings):


    appAuth = box_settings["boxAppSettings"]["appAuth"]
    privateKey = appAuth["privateKey"]
    passphrase = appAuth["passphrase"]

    # https://cryptography.io/en/latest/
    key = load_pem_private_key(
        data=privateKey.encode('utf8'),
        password=passphrase.encode('utf8'),
        backend=default_backend(),
    )

    # information to connect to the box API using the developer portal information
    auth = JWTAuth (
        client_id = box_settings["boxAppSettings"]["clientID"],
        client_secret = box_settings["boxAppSettings"]["clientSecret"],

        enterprise_id = box_settings["enterpriseID"],
        jwt_key_id = box_settings["boxAppSettings"]["appAuth"]["publicKeyID"],
        rsa_private_key_data = key
    )

    client = Client(auth)

    return client

# function to create session to generic read service and generate ge tokens when expired
def geApiSession(timeout):

    now = datetime.datetime.now()
    
    if "ge_access_token" not in globals():
        global ge_access_token
        global token_timeout

    if "form_api_session" not in globals():
        global form_api_session
        form_api_session = requests.Session()

    if now >= timeout:

        print("Getting new GE API token. Current is expired.")
        attempts = 1
        while attempts <= 5:
            try:
                #geToken = requests.post('https://fssfed.ge.com/fss/as/token.oauth2?grant_type=client_credentials&client_id={}&client_secret={}&scope=api'.format(oauth['clientId'],oauth['secret']))
                username, password = get_credentials()
                print('Username:', username)
                print('\nPassword:', password)
                #url = f"https://fssfed.ge.com/fss/as/token.oauth2?grant_type=client_credentials&client_id={username}&client_secret={password}&scope=api"
                url = f"https://efs.sso.gehealthcare.com/fss/as/token.oauth2?grant_type=client_credentials&client_id={username}&client_secret={password}&scope=api"
                print('url:', url)
                payload = {}
                headers = {}
                
                # Make the second API call
                geToken = requests.post(url, headers=headers, data=payload)

                # Print the response from the second API call
                if geToken.ok:
                    token_info = geToken.json()
                    access_token = token_info['access_token']
                    token_type = token_info['token_type']
                    expires_in = token_info['expires_in']
                    
                    print('\nAccess Token-Second call:', access_token)
                    print('\ngeToken json :', geToken.json())
                    #print('Token Type:', token_type)
                    #print('Expires In:', expires_in)
                else:
                    print('\nError Code ' + str(geToken.status_code))
                    print(geToken.text)
                            
            except:
                print("\ntoken error")
                attempts += 1
                time.sleep(random.randint(5,20) * attempts)
            else:

                headers = { #cg : might change from ge  user to gehc
                    "Authorization": "Bearer {}".format(geToken.json()["access_token"]),
                    "SM_USER": 'NP700002342', #'504005682',
                    "Content-Type": "application/JSON"
                }

                form_api_session.headers.update(headers)
                token_timeout = now + datetime.timedelta(seconds=geToken.json()['expires_in'] - 120)
                break

#function to pull user information from GE LDAP using the generic read service
def formRequestsLookup(id,filter_field,filter_value,operator,multiple=False):

    if "token_timeout" in globals():
        geApiSession(token_timeout)
    else:
        geApiSession(datetime.datetime.now())

    formFields = formFieldsLookup(id).json()

    field_arr = ["record_id","dt_created","created_by","proxy_created_by","dt_updated","updated_by"]

    if multiple is False:
        for field in formFields['fields']:
            field_arr.append(field['field_id'])
            if field['display_name'] == filter_field:
                field_id = field['field_id']
                if 'choices' in field:
                    for choice in field['choices']:
                        if choice['label'] == filter_value:
                            filter = choice['id']
                else:
                    filter = filter_value

        body = {"offset":0,"limit":500,
            "fields": field_arr,
            "filters":{"andor":[{"field_id":f"{field_id}","operator":f"{operator}","conjuction":"","value":filter,"operatorName":f"{operator}","operatorvalue":"","id":1}],
                "filterCriteria":"filter_1","sort":{"field_id":"dt_updated","order":"desc"}},
                "sort":{"field_id":"dt_updated","order":"desc"},
                "parent_record_id":0,
                "case_sensitive":False}
    else:
        count = 0
        multi_filter = []
        for filter_field_value in filter_field:
            for field in formFields['fields']:
                field_arr.append(field['field_id'])
                if field['display_name'] == filter_field_value:
                    if 'choices' in field:
                        for choice in field['choices']:
                            if choice['label'] == filter_value[count]:
                                multi_filter.append({"field_id":field['field_id'],"operator":f"{operator[count]}","conjuction":"AND","value":choice['id'],"operatorName":f"{operator[count]}","operatorvalue":"","id":(count + 1)})
                    else:
                        multi_filter.append({"field_id":field['field_id'],"operator":f"{operator[count]}","conjuction":"AND","value":filter_value[count],"operatorName":f"{operator[count]}","operatorvalue":"","id":(count + 1)})
            count += 1
        
        filter_count = 0
        for filter in multi_filter:
            filter_count += 1
            if "criteria" not in locals():
                criteria = f"filter_{filter_count}"
            else:
                criteria = f"{criteria} AND filter_{filter_count}"

        body = {"offset":0,"limit":500,
                "fields": field_arr,
                "filters":{"andor":multi_filter,
                    "filterCriteria":f"{criteria}","sort":{"field_id":field['field_id'],"order":"desc"}},
                    "sort":{"field_id":field['field_id'],"order":"desc"},
                    "parent_record_id":0,"case_sensitive":False}
        
    attempts = 0
    while True:
        try:
            attempts += 1
                                    #Change  to https://prod-api.gehealthcare.com/digital/formsv3_2l/api/v3/forms
            formQuery = form_api_session.post(f'https://prod-api.gehealthcare.com/digital/formsv3_2l/api/v3/forms/{id}/records',timeout = 60,json=body)
            #formQuery = form_api_session.post(f'https://api.ge.com/digital/ngformsv3/api/v3/forms/{id}/records',timeout = 60,json=body)
        except Exception as e:
            print(f"GE API request exception triggered. Trying again. Attempt: {attempts}")
            print(e)
            if attempts == 10:
                print("Forms API request exeptions hit maximum attempts")
                break
            else:
                time.sleep(5 * attempts)
        else:
            break
    
    return formQuery

def formFieldsLookup(id):
    
    if "token_timeout" in globals():
        geApiSession(token_timeout)
    else:
        geApiSession(datetime.datetime.now())

    attempts = 0
    while True:
        try:
            attempts += 1
            geApiSession(token_timeout)
            formFields = form_api_session.get(f'https://prod-api.gehealthcare.com/digital/formsv3_2l/api/v3/forms/{id}',timeout = 60)
            #formFields = form_api_session.get(f'https://api.ge.com/digital/ngformsv3/api/v3/forms/{id}',timeout = 60)
        except Exception as e:
            print(f"GE API request exception triggered. Trying again. Attempt: {attempts}")
            print(e)
            if attempts == 10:
                print("Forms API request exeptions hit maximum attempts")
                break
            else:
                time.sleep(5 * attempts)
                continue
        else:
            if 'fields' not in formFields.json():
                print(formFields.json())
                if attempts < 5:
                    time.sleep(300)
                    continue
                else:
                    print("unable to get fields from form fields")
                    sys.exit(1)
            else:
                return formFields

def formRecordLookup(id):

    if "token_timeout" in globals():
        geApiSession(token_timeout)
    else:
        geApiSession(datetime.datetime.now())

    attempts = 0
    while True:
        try:
            attempts += 1
            recordQuery = form_api_session.get(f"https://prod-api.gehealthcare.com/digital/formsv3_2l/api/v3/records/{id}",timeout = 60)
            #recordQuery = form_api_session.get(f"https://api.ge.com/digital/ngformsv3/api/v3/records/{id}",timeout = 60)
        except Exception as e:
            print(f"GE API request exception triggered. Trying again. Attempt: {attempts}")
            print(e)
            if attempts == 10:
                print("Forms API request exeptions hit maximum attempts")
                break
            else:
                time.sleep(5 * attempts)
                continue
        else:
            break
    
    return recordQuery

def createRequest(autoFormId,userFormId,request):

    if "token_timeout" in globals():
        geApiSession(token_timeout)
    else:
        geApiSession(datetime.datetime.now())

    recordQuery = formRecordLookup(request['record_id'])
    userFormFields = formFieldsLookup(userFormId)
    autoFormFields = formFieldsLookup(autoFormId)
    
    userData = {}
    for field in userFormFields.json()['fields']:
        if 'enclosed_fields' in field:
            for id in field['enclosed_fields']:
                for dataField in userFormFields.json()['fields']:
                    if str(dataField['field_id']) == id:
                        userData.update({
                            dataField['field_id']: dataField
                        }
                        )
    
    # matching the field ID's of the user form to fill out the fields in the automation form
    # we match the display names of the user form field to the auto form field
    # unless the field is a choices field, we match the label of the choice to the choice in the automation form
    body = {}
    for field in autoFormFields.json()['fields']:
        if 'enclosed_fields' in field:
            for id in field['enclosed_fields']:
                for autoField in autoFormFields.json()['fields']:
                    if str(autoField['field_id']) == id:
                        for fieldId in userData:
                            if userData[fieldId]['display_name'] in autoField['display_name']:
                                if "choices" not in autoField:
                                    if recordQuery.json()["field_" + str(fieldId)][0] != "":
                                        matched_field = recordQuery.json()["field_" + str(fieldId)]
                                    else:
                                        matched_field = None
                                else:
                                    for choice in autoField['choices']:
                                        if choice['label'] == request[f'field_{fieldId}'][0]:
                                            matched_field = [str(choice['id'])]
                                            break
                                        else:
                                            matched_field = None
                                
                                if matched_field is not None:
                                    if (autoField['field_type'] == 'peoplesearch') or (autoField['field_type'] == 'select'):
                                        matched_field = [int(matched_field[0])]
                                    elif autoField['field_type'] == 'radio':
                                        matched_field = [str(matched_field[0])]
                                    else:
                                        matched_field = [str(matched_field[0])]

                                    body.update({
                                        "field_" + str(autoField['field_id']): matched_field
                                    })
    
    # grabbing the field id of the people search field
    # in order to create the request impersonating the user who needs personal data from the record
    for userDataFieldId in userData:
        if (userData[userDataFieldId]['field_type'] == 'peoplesearch'):
            body.update({
                "proxy_created_by": int(recordQuery.json()[f"field_{userData[userDataFieldId]['field_id']}"][0])
            })
            break

    body.update({
        "form_id": str(autoFormId)
    }
    )
    print(body)

    attempts = 0
    while True:
        try:
            attempts += 1
            createRequestOutput = form_api_session.post(f'https://prod-api.gehealthcare.com/digital/formsv3_2l/api/v3/forms/{autoFormId}/record',timeout = 60,json=body)
           # createRequestOutput = form_api_session.post(f'https://api.ge.com/digital/ngformsv3/api/v3/forms/{autoFormId}/record',timeout = 60,json=body)
        except Exception as e:
            print(f"GE API request exception triggered. Trying again. Attempt: {attempts}")
            print(e)
            if attempts == 10:
                print("Forms API request exeptions hit maximum attempts")
                break
            else:
                time.sleep(5 * attempts)
                continue
        else:
            break
    
    return createRequestOutput

def updateRecord(formId,recordId,updateField,fieldType,updateValue):
    
    if "token_timeout" in globals():
        geApiSession(token_timeout)
    else:
        geApiSession(datetime.datetime.now())
    
    formFields = formFieldsLookup(formId).json()

    body = {
        "record_id": f"{recordId}",
        "form_id": f"{formId}"
    }

    for field in formFields['fields']:
        if field['display_name'] == updateField:
            if fieldType == "choice":
                for choice in field['choices']:
                    if choice['label'] == updateValue:
                        body.update({
                            f"field_{field['field_id']}": [str(choice['id'])]
                        })
            elif fieldType == "date":
                body.update({
                    f"field_{field['field_id']}": [updateValue.strftime('%Y-%m-%d %H:%M')]
                })
            elif (fieldType == "number") or (fieldType == "text"):
                body.update({
                    f"field_{field['field_id']}": [updateValue]
                })

    attempts = 0
    while True:
        try:
            attempts += 1
            recordUpdate = form_api_session.put(f"https://prod-api.gehealthcare.com/digital/formsv3_2l/api/v3/records/{recordId}",timeout = 60,json=body)
            #recordUpdate = form_api_session.put(f"https://api.ge.com/digital/ngformsv3/api/v3/records/{recordId}",timeout = 60,json=body)
        except Exception as e:
            print(f"GE API request exception triggered. Trying again. Attempt: {attempts}")
            print(e)
            if attempts == 10:
                print("Forms API request exeptions hit maximum attempts")
                break
            else:
                time.sleep(5 * attempts)
                continue
        else:
            break
    
    return recordUpdate

def createBoxFolder(id,sso,email,recordId):
    
    subfolder = box_client.folder(f"{id}").create_subfolder(f"{sso}_PersonalData_{recordId}")
    print(f'Created subfolder with ID {subfolder.id}')

    box_client.auth.authenticate_instance()

    request = {
        "item": {
            "type": "folder",
            "id": f"{subfolder.id}"
        },
        "accessible_by": {
            "type": "user",
            "login": f"{email}"
        },
        "role": "editor"
    }
    headers = {
        "Authorization": f"Bearer {box_client.auth.access_token}",
        "Content-Type": "application/json"
    }

    attempts = 0
    while True:
        try:
            attempts += 1
            collaboration = requests.post("https://api.box.com/2.0/collaborations", headers=headers,json=request)
        except:
            print(f"error adding collaborator: {user}, folder id: {subfolder.id}")
            print(collaboration.json())
            if attempts > 5:
                break
        else:
            if 'code' in collaboration.json():
                if collaboration.json()['code'] != 'user_already_collaborator':
                    print("error adding user as collaborator. Retrying...")
                    if attempts < 5:
                        continue
                    else:
                        print(id,sso,email,recordId)
                        print(collaboration.json())
                        removeBoxFolder(subfolder.id,"")
                        break
                else:
                    collaborations = box_client.folder(folder_id=f"{subfolder.id}").get_collaborations()
                    for collab in collaborations:
                        if collab.response_object['accessible_by']['type'] != "group":
                            if (collab.accessible_by.login).casefold() == email.casefold():
                                print(f"found existing collaboration using {email}.")
                                collab_id = collab.id
            else:
                collab_id = collaboration.json()['id']

            shared_lnk_attempts = 0
            while True:
                try:
                    shared_lnk_attempts += 1
                    url = box_client.folder(subfolder.id).get_shared_link(access='collaborators')
                except Exception as e:
                    print(e)
                    if shared_lnk_attempts > 5:
                        break
                else:
                    print(f'The folder shared link URL is: {url}')
                    break
            break

    return url,subfolder.id,collab_id

def removeBoxCollaboration(collabId):

    try:
        result = box_client.collaboration(collabId).delete()
    except Exception as e:
        if e.code == "not_found":
            result = True
        else:
            result = False

    return result

def addBoxCollaborator(folderId,user,expiration):
    
    box_client.auth.authenticate_instance()

    #correcting common errors in email addresses

    if ",com" in user:
        user = user.replace(",com",".com")
    
    if ".." in user:
        user = user.replace("..",".")

    request = {
        "item": {
            "type": "folder",
            "id": f"{folderId}"
        },
        "accessible_by": {
            "type": "user",
            "login": f"{user}"
        },
        "role": "viewer",
        "expires_at": expiration.strftime("%Y-%m-%dT%H:%M:%S")
    }
    headers = {
        "Authorization": f"Bearer {box_client.auth.access_token}",
        "Content-Type": "application/json"
    }

    attempts = 0
    while True:
        try:
            attempts += 1
            collaboration = requests.post("https://api.box.com/2.0/collaborations", headers=headers,json=request)
        except:
            print(f"error adding collaborator: {user}, folder id: {folderId}")
        else:
            if ('code' in collaboration.json()) and (collaboration.json()['code'] != "user_already_collaborator"):
                print(collaboration.json())
                if attempts > 5:
                    raise Exception(collaboration.json()['code'])
            else:
                body = {
                    "shared_link": {
                        "unshared_at": (datetime.datetime.now() + timedelta(days=60)).strftime("%Y-%m-%dT%H:%M:%S")
                    }
                }

                shared_link_attempts = 0
                while True:
                    try:
                        shared_link_attempts += 1
                        update_shared_link = requests.put(f"https://api.box.com/2.0/folders/{folderId}?fields=shared_link",headers=headers,json=body)
                    except:
                        print("Error updating shared link. Retrying...")
                        if shared_link_attempts < 5:
                            continue
                        else:
                            collaboration.delete()
                            break
                    else:
                        if update_shared_link.json()["type"] == "error":
                            if shared_link_attempts < 5:
                                print("Error updating shared link. Deleting collaboration.")
                                print(update_shared_link.json())
                            else:
                                collaboration.delete()
                                break
                        else:
                            return collaboration
                break

def removeBoxFolder(id,url):
    
    if len(id) == 0:
        try:
            folder = box_client.get_shared_item(f'{url}')
            id = folder.id
        except Exception as e:
            print(e)
            print("could not find folder based on url {url}. folder id is empty.")
            
    try:
        folder_removal = box_client.folder(folder_id=id).delete()
    except boxsdk.exception.BoxAPIException as e:
        print(e)
        if e.code == "not_found":
            return True
    except Exception as e:
        print(e)
        sys.exit(1)
    else:
        return folder_removal

def updateWorkflowStep (step_uuid,body):
    geApiSession(token_timeout)

    attempts = 0
    while True:
        try:
            attempts += 1
            workflow_update = form_api_session.put(f"https://prod-api.gehealthcare.com/digital/formsv3_2l/api/v3/oneform/request/{step_uuid}?isFormData=true",timeout = 60,json=body)
            #workflow_update = form_api_session.put(f"https://api.ge.com/digital/ngformsv3/api/v3/oneform/request/{step_uuid}?isFormData=true",timeout = 60,json=body)
        except:
            print(f"failure to update workflow step: {step_uuid}")
            if attempts > 5:
                break
        else:
            break

    return workflow_update

# gathering tokens from Vault to connect to box sdk and generic read service
vault_token = vault_connect(username,password)

#attempts = 0
#while True:
#    try:
#        attempts += 1
#        header = {
#            "X-Vault-Token": vault_token
#        }
#
#        token = requests.get("https://dwt-vault.cloud.corporate.ge.com/v1/secret/box/prod/domain_allow_and_personal_data_requests/healthcare/GEHC_Box_PDR_Connector_11857328550",headers=header).json()['data']
        #use password value
#        oauth = requests.get("https://dwt-vault.cloud.corporate.ge.com/v1/secret/box/prod/domain_allow_and_personal_data_requests/healthcare/oauth",headers=header).json()['data']
    
#    except Exception as e:
#        print(e)
#        if attempts < 5:
#            time.sleep(300)
#        else:
#            print("Unable to get secrets from Vault. Exiting...")
#            sys.exit(1)
#    else:
#        break

# Define the hardcoded `boxsettings` dictionary

# Load the settings from the file
with open('/etc/rundeck/box_settings.json', 'r') as json_file:
    box_settings = json.load(json_file)


#box_client = get_box_client(token)
box_client = get_box_client(box_settings)

# gathering requests from user form to start automation workflow
pdrRequests = formRequestsLookup(userFormId,("workflow_created", "workflow_record"),("No", ""),("eq","hasnull"),multiple=True).json()

if len(pdrRequests) != 1:
    for request in pdrRequests['records']:
        record = formRecordLookup(request['record_id'])

        if (record.status_code == 200):
            print(f"creating workflow for request in user form. Userform id: {userFormId}. Record id: {request['record_id']}")
            workflow = createRequest(autoFormId,userFormId,request)
            
            if (workflow.status_code == 200) or (workflow.status_code == 201):
                print(f"Created new workflow record: {workflow.json()['record_id']}. Creating box folder for user: {record.json()['created_by']['email']}.")
                updateRecord(userFormId,request['record_id'],"workflow_record","text",workflow.json()['record_id'])
                for workflow_detail in workflow.json():
                    if workflow_detail == "requestSteps":
                        for step in workflow.json()[workflow_detail]:
                            if step['status'] == "OPEN":
                                record = formRecordLookup(workflow.json()['record_id'])
                                fields = formFieldsLookup(autoFormId)

                                updateRecord(userFormId,request['record_id'],"workflow_step_uuid","text",step['uuid'])
                                if (record.status_code == 200) and (fields.status_code == 200):
                                    try:
                                        url,subfolderId,collabId = createBoxFolder(box_folder_id,record.json()['created_by']['ssoId'],record.json()['created_by']['email'],workflow.json()['record_id'])
                                    except:
                                        print(f"cannot create subfolder in {box_folder_id}.")
                                        # sys.exit(1)
                                    else:
                                        body = {
                                            "record_id": f"{workflow.json()['record_id']}",
                                            "form_id": f"{workflow.json()['form_id']}"
                                        }
                                        for field in fields.json()['fields']:
                                            if field['display_name'] == "folder_id":
                                                body.update({
                                                    f"field_{field['field_id']}": [f"{subfolderId}"]
                                                })
                                            if field['display_name'] == "Personal Data Removal Folder URL":
                                                body.update({
                                                    f"field_{field['field_id']}": [f"{url}"]
                                                })
                                            if field['display_name'] == "userRequestId":
                                                body.update({
                                                    f"field_{field['field_id']}": [f"{request['record_id']}"]
                                                })
                                            if field['display_name'] == "internal_user_collab_id":
                                                body.update({
                                                    f"field_{field['field_id']}": [f"{collabId}"]
                                                })
                                            if field['display_name'] == "ge_internal_email":
                                                body.update({
                                                    f"field_{field['field_id']}": [f"{record.json()['created_by']['email']}"]
                                                })
                                        body.update({
                                            "action": "APPROVE"
                                        })
                                        try:
                                            workflow_step = updateWorkflowStep(step['uuid'],body)
                                        except:
                                            print("failure to update step")
                                            updateRecord(userFormId,request['record_id'],"workflow_attempts","number","1")
                                        else:
                                            if workflow_step.status_code == 200:
                                                updateRecord(userFormId,request['record_id'],"workflow_created","choice","Yes")
                                                updateRecord(userFormId,request['record_id'],"workflow_attempts","number","1")
                                            else:
                                                print(f"cannot update the user form with workflow_created field. User form id: {userFormId}, record id: {request['record_id']}")
                                                updateRecord(userFormId,request['record_id'],"workflow_attempts","number","1")
                                            break
                                else:
                                    print(f"cannot read the record id: {workflow.json()['record_id']} or the automation form fields in form {autoFormId}. Record status code: {record.status_code}. Fields status code: {fields.status_code}")
            else:
                print(f"cannot create workflow. Status code of: {workflow.status_code}. Error Message: {workflow.text}")
                sys.exit(1)
        else:
            print(f"cannot read the user form record id: {request['record_id']} or the user form fields in form {userFormId}")
            sys.exit(1)

# gathering requests from user form to start automation workflow
pdrRetryRequests = formRequestsLookup(userFormId,("workflow_created", "workflow_record"),("No", ""),("eq","hasValue"),multiple=True).json()

if len(pdrRetryRequests) != 1:
    for request in pdrRetryRequests['records']:
        record = formRecordLookup(request['record_id'])
        fields = formFieldsLookup(userFormId)
        
        if (record.status_code == 200) and (fields.status_code == 200):

            for field in fields.json()['fields']:
                if field['display_name'] == "workflow_record":
                    workflow_id = record.json()[f"field_{field['field_id']}"][0]
                elif field['display_name'] == "workflow_step_uuid":
                    workflow_step_uuid = record.json()[f"field_{field['field_id']}"][0]
                elif field['display_name'] == "workflow_attempts":
                    workflow_attempts = int(record.json()[f"field_{field['field_id']}"][0])
                    
            print(f"\nAttempting to run workflow id: {workflow_id} again after previous failure.")

            workflow_record = formRecordLookup(workflow_id)
            workflow_fields = formFieldsLookup(autoFormId)

            if (workflow_record.status_code == 200) and (workflow_fields.status_code == 200):

                try:
                    workflow_attempts += 1
                    url,subfolderId,collabId = createBoxFolder(box_folder_id,workflow_record.json()['created_by']['ssoId'],workflow_record.json()['created_by']['email'],workflow_record.json()['record_id'])
                except Exception as e:
                    print(f"cannot create subfolder in {box_folder_id}.")
                    updateRecord(userFormId,request['record_id'],"workflow_attempts","number",f"{workflow_attempts}")
                    print(e)
                    # sys.exit(1)
                else:
                    body = {
                        "record_id": f"{workflow_record.json()['record_id']}",
                        "form_id": f"{workflow_record.json()['form_id']}"
                    }
                    for field in workflow_fields.json()['fields']:
                        if field['display_name'] == "folder_id":
                            body.update({
                                f"field_{field['field_id']}": [f"{subfolderId}"]
                            })
                        if field['display_name'] == "Personal Data Removal Folder URL":
                            body.update({
                                f"field_{field['field_id']}": [f"{url}"]
                            })
                        if field['display_name'] == "userRequestId":
                            body.update({
                                f"field_{field['field_id']}": [f"{request['record_id']}"]
                            })
                        if field['display_name'] == "internal_user_collab_id":
                            body.update({
                                f"field_{field['field_id']}": [f"{collabId}"]
                            })
                        if field['display_name'] == "ge_internal_email":
                            body.update({
                                f"field_{field['field_id']}": [f"{record.json()['created_by']['email']}"]
                            })
                    body.update({
                        "action": "APPROVE"
                    })
                    try:
                        workflow_step = updateWorkflowStep(workflow_step_uuid,body)
                    except:
                        print("failure to update step")
                        update_record = updateRecord(userFormId,request['record_id'],"workflow_attempts","number",f"{workflow_attempts}")
                    else:
                        if workflow_step.status_code == 200:
                            update_record = updateRecord(userFormId,request['record_id'],"workflow_created","choice","Yes")
                        else:
                            print(f"cannot update the user form with workflow_created field. User form id: {userFormId}, record id: {request['record_id']}")
                            update_record = updateRecord(userFormId,request['record_id'],"workflow_attempts","number",f"{workflow_attempts}")
                            update_record = updateRecord(userFormId,request['record_id'],"workflow_record","text",workflow_record.json()['record_id'])
                        break

        else:
            print(f"cannot read the user form record id: {request['record_id']} or the user form fields in form {userFormId}")
            sys.exit(1)

folderRequests = formRequestsLookup(folderFormId,("external_user_added","process_status"),("No","APPROVED"),("eq","eq"),multiple=True).json()

if len(folderRequests) != 1:
    print("processing approved requests, writing external user to folder, removing internal collaboration.")
    for request in folderRequests['records']:
        fields = formFieldsLookup(folderFormId).json()
        for field in fields['fields']:
            if field['display_name'] == "internal_user_collab_id":
                internal_user_collab_id = f"field_{field['field_id']}"
            elif field['display_name'] == "External Email":
                external_mail_field = f"field_{field['field_id']}"
            elif field['display_name'] == "folderId":
                folderId = f"field_{field['field_id']}"
            elif field['display_name'] == "GE User":
                user = f"field_{field['field_id']}"
            elif field['display_name'] == "internal_ge_email":
                internal_email = f"field_{field['field_id']}"

        print(f"removing internal ge user from folder id: {request[folderId][0]} collaboration id: {request[internal_user_collab_id][0]}")
        remove_result = removeBoxCollaboration(request[internal_user_collab_id][0])
        if remove_result is True:
            update_record_internal_user = updateRecord(folderFormId,request['record_id'],"internal_user_removed","choice","Yes")
            if update_record_internal_user.status_code == 200:
                print(f"adding external box collaborator {request[external_mail_field][0]}")
                try:
                    add_result = addBoxCollaborator(request[folderId][0],request[external_mail_field][0],datetime.datetime.now() + timedelta(days=60))
                except Exception as e:
                    print(e)
                    updateRecord(folderFormId,request['record_id'],"error","text",e)
                if (add_result.status_code == 201) or ((add_result.status_code == 400) and (add_result.json()['code'] == "user_already_collaborator")):
                    print("successfully added external collaborator. Updating form.")
                    update_record_external_user = updateRecord(folderFormId,request['record_id'],"external_user_added","choice","Yes")
                    if update_record_external_user.status_code == 200:
                        update_record_external_user_date = updateRecord(folderFormId,request['record_id'],"external_share_created_date","date",datetime.datetime.now())
                        if update_record_external_user_date.status_code == 200:
                            update_record_external_share_date = updateRecord(folderFormId,request['record_id'],"external_share_expiration_date","date",datetime.datetime.now() + timedelta(days=60))
                            if update_record_external_share_date.status_code == 200:
                                update_record_folder_expiration_date = updateRecord(folderFormId,request['record_id'],"folder_expiration_date","date",datetime.datetime.now() + timedelta(days=105))
                    else:
                        print(f"error updating folder form: {folderFormId}.")
                        sys.exit(1)
                else:
                    print(f"error adding external user to folder. folder id: {request[folderId][0]}.")
        else:
            print("error removing internal user from folder.")
            sys.exit(1)

folderDeleteRequests = formRequestsLookup(folderFormId,("folder_deleted","folder_expiration_date"),("No",(datetime.datetime.now() - timedelta(days=105)).strftime("%Y-%m-%d %H:%M")),("eq","lt"),multiple=True).json()

if len(folderDeleteRequests) != 1:
    for request in folderDeleteRequests['records']:
        fields = formFieldsLookup(folderFormId).json()
        for field in fields['fields']:
            if field['display_name'] == "folder_expiration_date":
                folder_expiration_date = f"field_{field['field_id']}"
            if field['display_name'] == "folderId":
                folderId = f"field_{field['field_id']}"
            if field['display_name'] == 'folder_url':
                folder_url = f"field_{field['field_id']}"
        
        if request[f"{folder_expiration_date}"][0] != "":
            if datetime.datetime.strptime(request[f"{folder_expiration_date}"][0],"%Y-%m-%d %H:%M") < datetime.datetime.now():
                folderRemove_result = removeBoxFolder(request[folderId][0],request[folder_url][0])
                if folderRemove_result is True:
                    folderDeleted = updateRecord(folderFormId,request['record_id'],"folder_deleted","choice","Yes")
                    if folderDeleted.status_code == 200:
                        folderDeleted_date = updateRecord(folderFormId,request['record_id'],"folder_deleted_date","date",datetime.datetime.now())

folderRejectedRequests = formRequestsLookup(folderFormId,("process_status","folder_deleted"),("REJECTED","No"),("eq","eq"),multiple=True).json()

if len(folderRejectedRequests) != 1:
    for request in folderRejectedRequests['records']:
        fields = formFieldsLookup(folderFormId).json()
        for field in fields['fields']:
            if field['display_name'] == "folderId":
                folderId = f"field_{field['field_id']}"
            if field['display_name'] == 'folder_url':
                folder_url = f"field_{field['field_id']}"
        
        folderRemove_result = removeBoxFolder(request[folderId][0],request[folder_url][0])
        if folderRemove_result is True:
            folderDeleted = updateRecord(folderFormId,request['record_id'],"folder_deleted","choice","Yes")
            if folderDeleted.status_code == 200:
                folderDeleted_date = updateRecord(folderFormId,request['record_id'],"folder_deleted_date","date",datetime.datetime.now())
                
